# -*- coding: utf-8 -*-
"""
Static Precision Analysis Module — instantaneous-velocity approach.

Detects static segments automatically: an epoch is considered "static"
if the instantaneous ground speed (horizontal distance to previous epoch
divided by the time interval) is below a user-defined threshold (cm/s).
Contiguous static epochs are merged into segments; only segments with
at least `min_epochs` consecutive epochs are retained.

For each detected segment the module computes ENU statistics
(mean position, std, RMS, max deviation) relative to the segment centroid.
"""

import math
import numpy as np
from qgis.core import QgsProject


# ── UTC helper ────────────────────────────────────────────────────────────────

def _sod_to_hms(sod):
    """Convert seconds-of-day (float) to 'HH:MM:SS' UTC string."""
    sod = float(sod)
    h   = int(sod // 3600)
    m   = int((sod % 3600) // 60)
    s   = sod % 60
    return f"{h:02d}:{m:02d}:{s:05.2f}"


# ── WGS84 ─────────────────────────────────────────────────────────────────────
_a  = 6378137.0
_f  = 1 / 298.257223563
_e2 = 2 * _f - _f * _f


def _ecef_from_lla(lat_deg, lon_deg, h):
    """Vectorised geodetic -> ECEF."""
    lat = np.radians(lat_deg)
    lon = np.radians(lon_deg)
    sl = np.sin(lat); cl = np.cos(lat)
    N = _a / np.sqrt(1 - _e2 * sl**2)
    X = (N + h) * cl * np.cos(lon)
    Y = (N + h) * cl * np.sin(lon)
    Z = (N * (1 - _e2) + h) * sl
    return X, Y, Z


def _ecef_to_geodetic_scalar(X, Y, Z):
    """Iterative ECEF -> geodetic (single point, returns radians)."""
    lon = math.atan2(Y, X)
    p = math.sqrt(X*X + Y*Y)
    lat = math.atan2(Z, p * (1 - _e2))
    for _ in range(5):
        sl = math.sin(lat)
        N = _a / math.sqrt(1 - _e2 * sl * sl)
        h = p / math.cos(lat) - N
        lat = math.atan2(Z, p * (1 - _e2 * N / (N + h)))
    sl = math.sin(lat)
    N = _a / math.sqrt(1 - _e2 * sl * sl)
    h = p / math.cos(lat) - N
    return lat, lon, h


def _enu_from_ecef(X, Y, Z, Xr, Yr, Zr, lat_r, lon_r):
    """Vectorised ECEF -> ENU."""
    sl = np.sin(lat_r); cl = np.cos(lat_r)
    sn = np.sin(lon_r); cn = np.cos(lon_r)
    dX = X - Xr; dY = Y - Yr; dZ = Z - Zr
    E = -sn*dX + cn*dY
    N_val = -sl*cn*dX - sl*sn*dY + cl*dZ
    U = cl*cn*dX + cl*sn*dY + sl*dZ
    return E, N_val, U


# ── Segment detection ─────────────────────────────────────────────────────────

def detect_static_segments(X, Y, Z, ts, min_epochs, speed_threshold_ms):
    """
    Detect contiguous static segments using instantaneous ground speed.

    For each consecutive pair of epochs, the 3D ECEF distance is divided
    by the time interval to obtain the speed (m/s).  An epoch is "static"
    if the speed from the previous epoch is below `speed_threshold_ms`.
    The first epoch inherits the status of the second.  Contiguous static
    epochs are merged into segments; only segments with at least
    `min_epochs` points are retained.

    Returns
    -------
    list of (start_idx, end_idx) — inclusive on both sides.
    """
    n = len(ts)
    if n < min_epochs:
        return []

    dX = np.diff(X)
    dY = np.diff(Y)
    dZ = np.diff(Z)
    dist = np.sqrt(dX**2 + dY**2 + dZ**2)

    dt = np.diff(ts)
    dt[dt == 0] = 1e-6

    speed = dist / dt  # m/s

    is_static = np.zeros(n, dtype=bool)
    is_static[1:] = speed < speed_threshold_ms
    is_static[0]  = is_static[1] if n > 1 else False

    segments = []
    in_seg = False
    start = 0
    for i in range(n):
        if is_static[i] and not in_seg:
            start = i
            in_seg = True
        elif not is_static[i] and in_seg:
            if (i - start) >= min_epochs:
                segments.append((start, i - 1))
            in_seg = False
    if in_seg and (n - start) >= min_epochs:
        segments.append((start, n - 1))

    return segments


# ── Per-segment statistics ────────────────────────────────────────────────────

def analyze_segment(lat, lon, h, ts):
    """
    Compute ENU statistics for a single static segment.
    """
    X, Y, Z = _ecef_from_lla(lat, lon, h)
    Xm = float(np.mean(X)); Ym = float(np.mean(Y)); Zm = float(np.mean(Z))
    lat_r, lon_r, h_r = _ecef_to_geodetic_scalar(Xm, Ym, Zm)

    E, N, U = _enu_from_ecef(X, Y, Z, Xm, Ym, Zm, lat_r, lon_r)
    horiz = np.sqrt(E**2 + N**2)

    return {
        "n_epochs":    len(lat),
        "ts_start":    float(ts[0]),
        "ts_end":      float(ts[-1]),
        "duration_s":  float(ts[-1] - ts[0]),
        "lat_mean":    float(np.mean(lat)),
        "lon_mean":    float(np.mean(lon)),
        "h_mean":      float(np.mean(h)),
        "std_E":       float(np.std(E)),
        "std_N":       float(np.std(N)),
        "std_U":       float(np.std(U)),
        "rms_E":       float(np.sqrt(np.mean(E**2))),
        "rms_N":       float(np.sqrt(np.mean(N**2))),
        "rms_U":       float(np.sqrt(np.mean(U**2))),
        "rms_horiz":   float(np.sqrt(np.mean(horiz**2))),
        "max_E":       float(np.max(np.abs(E))),
        "max_N":       float(np.max(np.abs(N))),
        "max_U":       float(np.max(np.abs(U))),
        "max_horiz":   float(np.max(horiz)),
    }


# ── Field-name detection ──────────────────────────────────────────────────────

def _detect_coord_fields(field_names):
    """
    Return (ts_field, lat_field, lon_field, h_field) for the given set of
    field names, supporting all layer types produced by the plugin:

      • Consensus layers   : timestamp  / latitude    / longitude    / height
      • Raw input layers   : Timestamp  / Latitude    / Longitude    / Height
      • Baseline_AB_Plan/V : timestamp_sod / lat_mean_deg / lon_mean_deg / h_mean_m

    Returns None if no recognised combination is found.
    """
    fset = set(field_names)
    if "timestamp" in fset and "latitude" in fset:
        return "timestamp", "latitude", "longitude", "height"
    if "Timestamp" in fset and "Latitude" in fset:
        return "Timestamp", "Latitude", "Longitude", "Height"
    if "timestamp_sod" in fset and "lat_mean_deg" in fset:
        return "timestamp_sod", "lat_mean_deg", "lon_mean_deg", "h_mean_m"
    return None


# ── Main entry point ─────────────────────────────────────────────────────────

def analyze_static_precision(layer_name, min_epochs, speed_threshold_cms):
    """
    Detect static segments in a layer and analyse each one.

    Parameters
    ----------
    layer_name : str
        QGIS layer name — any layer produced by the plugin is supported:
        raw input layers (Ant_A_RS1 …), Consensus_A/B, Baseline_AB_Plan/Vert.
    min_epochs : int
        Minimum number of consecutive epochs to define a static segment.
    speed_threshold_cms : float
        Maximum instantaneous ground speed in cm/s for an epoch to be
        considered static.

    Returns
    -------
    dict with keys:
        "segments": list of per-segment stats dicts
        "n_total":  total epochs in the layer
        "n_static": total epochs classified as static
        "speed_threshold_cms": the threshold used
    """
    lys = QgsProject.instance().mapLayersByName(layer_name)
    if not lys:
        raise ValueError(f"Layer '{layer_name}' not found.")
    layer = lys[0]

    field_names = [f.name() for f in layer.fields()]

    coord_fields = _detect_coord_fields(field_names)
    if coord_fields is None:
        raise ValueError(
            f"Layer '{layer_name}' has no recognised coordinate fields.\n"
            "Supported field sets:\n"
            "  • timestamp / latitude / longitude / height  (Consensus layers)\n"
            "  • Timestamp / Latitude / Longitude / Height  (raw input layers)\n"
            "  • timestamp_sod / lat_mean_deg / lon_mean_deg / h_mean_m  (Baseline layers)")
    ts_f, lat_f, lon_f, h_f = coord_fields

    rows = []
    for feat in layer.getFeatures():
        ts  = feat[ts_f]
        lat = feat[lat_f]
        lon = feat[lon_f]
        h   = feat[h_f]
        # Skip NULL, empty strings
        if any(v is None for v in (ts, lat, lon, h)):
            continue
        if any(isinstance(v, str) and v.strip() == "" for v in (ts, lat, lon, h)):
            continue
        try:
            ts_v, lat_v, lon_v, h_v = float(ts), float(lat), float(lon), float(h)
        except (TypeError, ValueError):
            continue
        # Skip NaN / infinite (corrupted epochs that would skew statistics)
        if any(not math.isfinite(v) for v in (ts_v, lat_v, lon_v, h_v)):
            continue
        # Skip zero-solution epochs (receiver no-fix: all coordinate fields = 0)
        if lat_v == 0.0 and lon_v == 0.0 and h_v == 0.0:
            continue
        rows.append((ts_v, lat_v, lon_v, h_v))

    if len(rows) < min_epochs:
        raise ValueError(
            f"Not enough valid epochs ({len(rows)}) — need at least {min_epochs}.")

    rows.sort(key=lambda r: r[0])
    ts_arr  = np.array([r[0] for r in rows])
    lat_arr = np.array([r[1] for r in rows])
    lon_arr = np.array([r[2] for r in rows])
    h_arr   = np.array([r[3] for r in rows])

    X, Y, Z = _ecef_from_lla(lat_arr, lon_arr, h_arr)

    speed_threshold_ms = speed_threshold_cms / 100.0

    segments = detect_static_segments(X, Y, Z, ts_arr,
                                       min_epochs, speed_threshold_ms)

    seg_stats = []
    n_static = 0
    seg_id = 0
    for s, e in segments:
        sl = slice(s, e + 1)
        st = analyze_segment(lat_arr[sl], lon_arr[sl], h_arr[sl], ts_arr[sl])
        n_static += st["n_epochs"]
        # Skip segments where all ENU deviations are negligible (<1 µm):
        # the receiver froze on a constant solution (all epochs identical or
        # differing only by floating-point rounding noise in the ECEF conversion).
        if st["max_horiz"] < 1e-6 and st["max_U"] < 1e-6:
            continue
        seg_id += 1
        st["segment_id"] = seg_id
        seg_stats.append(st)

    return {
        "segments": seg_stats,
        "n_total":  len(rows),
        "n_static": n_static,
        "speed_threshold_cms": speed_threshold_cms,
    }


def format_combined_report(result_a, result_b, name_a, name_b,
                            unit_factor=1.0, unit_label="m"):
    """
    Format a combined report from two layers sorted chronologically.
    Segments are interleaved by ts_start; ties put layer-1 (A) before layer-2 (B).
    """
    f = unit_factor
    u = unit_label

    # Tag every segment with its source label and name
    tagged = []
    for seg in result_a["segments"]:
        tagged.append((seg["ts_start"], 0, "1", name_a, seg))
    for seg in result_b["segments"]:
        tagged.append((seg["ts_start"], 1, "2", name_b, seg))

    # Sort chronologically; within the same second Layer 1 comes first
    tagged.sort(key=lambda x: (x[0], x[1]))

    total_a = len(result_a["segments"])
    total_b = len(result_b["segments"])

    lines = [
        "=" * 70,
        "  STATIC PRECISION ANALYSIS — COMBINED (chronological order)",
        "=" * 70,
        f"  Layer 1: {name_a}   {result_a['n_total']} epochs   "
        f"{total_a} segment(s)   threshold: {result_a['speed_threshold_cms']:.1f} cm/s",
        f"  Layer 2: {name_b}   {result_b['n_total']} epochs   "
        f"{total_b} segment(s)   threshold: {result_b['speed_threshold_cms']:.1f} cm/s",
        "=" * 70,
    ]

    if not tagged:
        lines.append(
            "\n  No static segments detected in either layer.\n"
            "  Try increasing the speed threshold or reducing the minimum epochs.")
        lines.append("\n" + "=" * 70)
        return "\n".join(lines)

    for _, _, lbl, name, s in tagged:
        dur = s['duration_s']
        dur_str = f"{dur:.0f} s" if dur < 60 else f"{dur/60:.1f} min"
        lines.append(
            f"\n  ── Segment {s['segment_id']}  [Layer {lbl}: {name}]  "
            f"({s['n_epochs']} epochs, {dur_str},  "
            f"{_sod_to_hms(s['ts_start'])} – {_sod_to_hms(s['ts_end'])} UTC) ──")
        lines.append(
            f"  Mean position: "
            f"lat = {s['lat_mean']:.8f} deg   "
            f"lon = {s['lon_mean']:.8f} deg   "
            f"h = {s['h_mean']:.3f} m")
        lines.append("")
        lines.append(
            f"  {'Component':<12} {'Std':>12} {'RMS':>12} {'Max':>12}")
        lines.append(
            f"  {'-'*12} {'-'*12} {'-'*12} {'-'*12}")
        for comp, std_k, rms_k, max_k in [
            ("East",  "std_E", "rms_E", "max_E"),
            ("North", "std_N", "rms_N", "max_N"),
            ("Up",    "std_U", "rms_U", "max_U"),
        ]:
            std_v = f"{s[std_k]*f:.4f} {u}" if std_k else "---"
            rms_v = f"{s[rms_k]*f:.4f} {u}"
            max_v = f"{s[max_k]*f:.4f} {u}"
            lines.append(
                f"  {comp:<12} {std_v:>12} {rms_v:>12} {max_v:>12}")

    lines.append("\n" + "=" * 70)
    return "\n".join(lines)


def format_report(result, unit_factor=1.0, unit_label="m", header=None):
    """
    Format the analysis result into a human-readable report string.
    `header` is an optional layer name shown in the title line.
    """
    f = unit_factor
    u = unit_label
    title = f"  STATIC PRECISION ANALYSIS — {header}" if header else \
            "  STATIC PRECISION ANALYSIS - REPORT"
    lines = [
        "=" * 70,
        title,
        "=" * 70,
        f"  Detection criterion : instantaneous speed < "
        f"{result['speed_threshold_cms']:.1f} cm/s",
        f"  Total epochs in layer : {result['n_total']}",
        f"  Static epochs detected: {result['n_static']}",
        f"  Static segments found : {len(result['segments'])}",
        "=" * 70,
    ]

    if not result["segments"]:
        lines.append(
            "\n  No static segments detected with the current parameters.\n"
            "  Try increasing the speed threshold or reducing the minimum epochs.")
        return "\n".join(lines)

    for s in result["segments"]:
        dur = s['duration_s']
        dur_str = (f"{dur:.0f} s" if dur < 60
                   else f"{dur/60:.1f} min")
        lines.append(
            f"\n  -- Segment {s['segment_id']}  "
            f"({s['n_epochs']} epochs, {dur_str}, "
            f"{_sod_to_hms(s['ts_start'])} – {_sod_to_hms(s['ts_end'])} UTC) --")
        lines.append(
            f"  Mean position: "
            f"lat = {s['lat_mean']:.8f} deg   "
            f"lon = {s['lon_mean']:.8f} deg   "
            f"h = {s['h_mean']:.3f} m")
        lines.append("")
        lines.append(
            f"  {'Component':<12} {'Std':>12} {'RMS':>12} {'Max':>12}")
        lines.append(
            f"  {'-'*12} {'-'*12} {'-'*12} {'-'*12}")
        for comp, std_k, rms_k, max_k in [
            ("East",       "std_E", "rms_E", "max_E"),
            ("North", "std_N", "rms_N", "max_N"),
            ("Up",    "std_U", "rms_U", "max_U"),
        ]:
            std_v = f"{s[std_k]*f:.4f} {u}" if std_k else "---"
            rms_v = f"{s[rms_k]*f:.4f} {u}"
            max_v = f"{s[max_k]*f:.4f} {u}"
            lines.append(
                f"  {comp:<12} {std_v:>12} {rms_v:>12} {max_v:>12}")

    lines.append("\n" + "=" * 70)
    return "\n".join(lines)
