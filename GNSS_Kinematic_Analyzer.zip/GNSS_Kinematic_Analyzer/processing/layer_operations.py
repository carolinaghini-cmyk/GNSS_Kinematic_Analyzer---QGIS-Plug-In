# -*- coding: utf-8 -*-
"""
Layer Operations Module - Utility functions
"""

from qgis.core import QgsProject


def get_layer_by_name(layer_name):
    """
    Get layer by name from QGIS project.
    
    Args:
        layer_name (str): Layer name
        
    Returns:
        QgsVectorLayer: The layer or None
    """
    layers = QgsProject.instance().mapLayersByName(layer_name)
    
    if layers:
        return layers[0]
    return None


def get_all_point_layers():
    """
    Get all point layers from current project.
    
    Returns:
        list: List of point layer names
    """
    from qgis.core import QgsWkbTypes
    
    point_layers = []
    for layer in QgsProject.instance().mapLayers().values():
        if layer.type() == 0:  # Vector layer
            if layer.geometryType() == QgsWkbTypes.PointGeometry:
                point_layers.append(layer.name())
    
    return point_layers