# -*- coding: utf-8 -*-
"""
RS Consensus Generation Module
================================
Creates a consensus layer from two _xgis layers of the same receiver
measured with two different RS stations.

No solution filter is applied here: filtering is done in Preprocessing.

Optimisations
─────────────
• Numpy-vectorised ENU computation (replaces per-epoch math calls)
• Single addFeatures() bulk call (no per-feature provider interaction)
• Index built as plain dict (no QGIS spatial index needed)

Output layer fields
───────────────────
timestamp, latitude, longitude, height,
X_ECEF, Y_ECEF, Z_ECEF,
dE_rs, dN_rs, dU_rs, RMS2D_rs, RMSUp_rs
"""

import math
import numpy as np
from qgis.core import (QgsProject, QgsVectorLayer, QgsField,
                       QgsFeature, QgsGeometry, QgsPointXY)
from qgis.PyQt.QtCore import QVariant

_a  = 6378137.0
_e2 = 0.00669437999014


# ── coordinate helpers (numpy-vectorised) ─────────────────────────────────────

def _lla_to_ecef_vec(lat_deg, lon_deg, h):
    lat = np.radians(lat_deg); lon = np.radians(lon_deg)
    N   = _a / np.sqrt(1.0 - _e2 * np.sin(lat)**2)
    X   = (N + h) * np.cos(lat) * np.cos(lon)
    Y   = (N + h) * np.cos(lat) * np.sin(lon)
    Z   = (N * (1.0 - _e2) + h) * np.sin(lat)
    return X, Y, Z


def _enu_vec(lat1, lon1, h1, lat2, lon2, h2):
    """Vectorised ENU(P1 − P2) centred on P1."""
    lat1r = np.radians(lat1); lon1r = np.radians(lon1)
    sl = np.sin(lat1r); cl = np.cos(lat1r)
    sn = np.sin(lon1r); cn = np.cos(lon1r)
    X1, Y1, Z1 = _lla_to_ecef_vec(lat1, lon1, h1)
    X2, Y2, Z2 = _lla_to_ecef_vec(lat2, lon2, h2)
    dX = X1 - X2; dY = Y1 - Y2; dZ = Z1 - Z2
    dE = -sn*dX + cn*dY
    dN = -sl*cn*dX - sl*sn*dY + cl*dZ
    dU =  cl*cn*dX + cl*sn*dY + sl*dZ
    return dE, dN, dU


# ── helpers ───────────────────────────────────────────────────────────────────

def _detect_fields(layer):
    names = {f.name() for f in layer.fields()}
    for ts in ("Timestamp", "timestamp"):
        if ts in names:
            sfx = "" if ts == "Timestamp" else ""
            return ts, "Latitude" if "Latitude" in names else "latitude", \
                       "Longitude" if "Longitude" in names else "longitude", \
                       "Height" if "Height" in names else "height"
    raise ValueError(
        f"Unrecognised field structure in layer '{layer.name()}'. "
        f"Available fields: {', '.join(sorted(names))}")


def _load_layer(layer, ts_f, lat_f, lon_f, h_f):
    """Load all features. Returns dict ts_sod → (lat, lon, h, geom, utc_str_or_None).
    Skips NULL, empty-string, NaN and infinite values."""
    field_names = {f.name() for f in layer.fields()}
    utc_f = "UTC_Time" if "UTC_Time" in field_names else None
    idx = {}
    for feat in layer.getFeatures():
        ts = feat[ts_f]
        if ts is None or (isinstance(ts, str) and ts.strip() == ""):
            continue
        lat = feat[lat_f]; lon = feat[lon_f]; h = feat[h_f]
        if None in (lat, lon, h):
            continue
        if any(isinstance(v, str) and v.strip() == "" for v in (lat, lon, h)):
            continue
        try:
            ts_v  = float(ts)
            lat_v = float(lat)
            lon_v = float(lon)
            h_v   = float(h)
        except (TypeError, ValueError):
            continue
        if any(not math.isfinite(v) for v in (ts_v, lat_v, lon_v, h_v)):
            continue
        utc_str = feat[utc_f] if utc_f else None
        idx[ts_v] = (lat_v, lon_v, h_v, feat.geometry(), utc_str)
    return idx


def _calc_stats(values):
    if not values:
        return {}
    s = sorted(values); n = len(s)
    mean = sum(values) / n
    std  = math.sqrt(sum((x - mean)**2 for x in values) / n)
    rms  = math.sqrt(sum(x**2 for x in values) / n)
    return {"mean": mean, "std": std, "rms": rms,
            "p95": s[min(int(n*0.95), n-1)], "max": s[-1]}


# ── main ──────────────────────────────────────────────────────────────────────

def create_vrs_consensus(layer_vrs1_name, layer_vrs2_name, output_name):
    """
    Create a consensus layer from two RS layers of the same antenna.
    Returns stats dict.
    """
    def _get(name):
        lys = QgsProject.instance().mapLayersByName(name)
        if not lys:
            raise ValueError(f"Layer '{name}' not found in project.")
        return lys[0]

    l1 = _get(layer_vrs1_name); l2 = _get(layer_vrs2_name)
    ts1, lat1f, lon1f, h1f = _detect_fields(l1)
    ts2, lat2f, lon2f, h2f = _detect_fields(l2)

    idx1 = _load_layer(l1, ts1, lat1f, lon1f, h1f)
    idx2 = _load_layer(l2, ts2, lat2f, lon2f, h2f)

    common = sorted(set(idx1) & set(idx2))
    if not common:
        raise ValueError("No common epochs between the two layers.")

    n = len(common)

    # Extract arrays for vectorised computation
    ts_arr  = np.array(common)
    lat1_a  = np.array([idx1[t][0] for t in common])
    lon1_a  = np.array([idx1[t][1] for t in common])
    h1_a    = np.array([idx1[t][2] for t in common])
    lat2_a  = np.array([idx2[t][0] for t in common])
    lon2_a  = np.array([idx2[t][1] for t in common])
    h2_a    = np.array([idx2[t][2] for t in common])

    avg_lat = (lat1_a + lat2_a) / 2.0
    avg_lon = (lon1_a + lon2_a) / 2.0
    avg_h   = (h1_a   + h2_a)   / 2.0

    Xa, Ya, Za = _lla_to_ecef_vec(avg_lat, avg_lon, avg_h)
    dE, dN, dU = _enu_vec(lat1_a, lon1_a, h1_a, lat2_a, lon2_a, h2_a)
    rms2d = np.sqrt(dE**2 + dN**2)
    rmsup = np.abs(dU)

    # Build output layer
    crs       = l1.crs().authid()
    out_layer = QgsVectorLayer(f"Point?crs={crs}", output_name, "memory")
    prov      = out_layer.dataProvider()
    prov.addAttributes([
        QgsField("timestamp",    QVariant.Double),
        QgsField("datetime_utc", QVariant.String),
        QgsField("latitude",     QVariant.Double),
        QgsField("longitude",    QVariant.Double),
        QgsField("height",       QVariant.Double),
        QgsField("X_ECEF",       QVariant.Double),
        QgsField("Y_ECEF",       QVariant.Double),
        QgsField("Z_ECEF",       QVariant.Double),
        QgsField("dE_rs",        QVariant.Double),
        QgsField("dN_rs",        QVariant.Double),
        QgsField("dU_rs",        QVariant.Double),
        QgsField("RMS2D_rs",     QVariant.Double),
        QgsField("RMSUp_rs",     QVariant.Double),
    ])
    out_layer.updateFields()

    # Build all features in one pass, then bulk-add
    feats = []
    for i in range(n):
        feat = QgsFeature(out_layer.fields())
        feat["timestamp"]    = float(ts_arr[i])
        feat["datetime_utc"] = idx1[common[i]][4] or ""
        feat["latitude"]     = round(float(avg_lat[i]), 8)
        feat["longitude"]    = round(float(avg_lon[i]), 8)
        feat["height"]     = round(float(avg_h[i]),   3)
        feat["X_ECEF"]     = round(float(Xa[i]), 3)
        feat["Y_ECEF"]     = round(float(Ya[i]), 3)
        feat["Z_ECEF"]     = round(float(Za[i]), 3)
        feat["dE_rs"]      = round(float(dE[i]), 5)
        feat["dN_rs"]      = round(float(dN[i]), 5)
        feat["dU_rs"]      = round(float(dU[i]), 5)
        feat["RMS2D_rs"]   = round(float(rms2d[i]), 5)
        feat["RMSUp_rs"]   = round(float(rmsup[i]), 5)

        # Geometry: average of RS1 and RS2 geometries
        g1 = idx1[common[i]][3]; g2 = idx2[common[i]][3]
        if g1 and g2:
            p1 = g1.asPoint(); p2 = g2.asPoint()
            feat.setGeometry(QgsGeometry.fromPointXY(
                QgsPointXY((p1.x()+p2.x())/2, (p1.y()+p2.y())/2)))
        feats.append(feat)

    prov.addFeatures(feats)        # single bulk call
    out_layer.updateExtents()
    QgsProject.instance().addMapLayer(out_layer)

    sync_rate = n / max(len(idx1), len(idx2)) * 100

    horiz_list = rms2d.tolist()
    height_list = np.abs(dU).tolist()
    dist3d = np.sqrt(
        (np.array([idx1[t][0] for t in common]) -
         np.array([idx2[t][0] for t in common]))**2 +
        (np.array([idx1[t][1] for t in common]) -
         np.array([idx2[t][1] for t in common]))**2 +
        (np.array([idx1[t][2] for t in common]) -
         np.array([idx2[t][2] for t in common]))**2
    ).tolist()

    return {
        "output_name":  output_name,
        "n_rs1":        len(idx1),
        "n_rs2":        len(idx2),
        "synchronized": n,
        "sync_rate":    sync_rate,
        "rs_stats": {
            "3d":         _calc_stats(dist3d),
            "horizontal": _calc_stats(horiz_list),
            "height":     _calc_stats(height_list),
        },
    }
