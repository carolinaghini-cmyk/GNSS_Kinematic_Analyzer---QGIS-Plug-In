# -*- coding: utf-8 -*-
"""
Visualization Module - Complete with all 6 plots
"""

from qgis.core import QgsProject
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import os


def _sod_formatter(x, pos):
    """Format seconds-of-day as HH:MM:SS for axis tick labels."""
    x = max(0.0, float(x))
    h = int(x // 3600) % 24
    m = int((x % 3600) // 60)
    s = int(x % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def generate_plots(layer_name, output_folder, 
                   plot_horiz_hist=True, 
                   plot_height_hist=True, 
                   plot_timeseries=True,
                   plot_boxplot=True,
                   plot_scatter_en=True,
                   plot_timeseries_height=True):
    """
    Generate analysis plots for inter-receiver data.
    
    Args:
        layer_name (str): Name of layer with inter-receiver fields
        output_folder (str): Folder to save plots
        plot_horiz_hist (bool): Horizontal distance histogram
        plot_height_hist (bool): Height difference histogram
        plot_timeseries (bool): Horizontal time series
        plot_boxplot (bool): Boxplot comparison
        plot_scatter_en (bool): E-N scatter plot
        plot_timeseries_height (bool): Height time series
        
    Returns:
        list: Paths to generated plot files
    """
    
    # Get layer
    layers = QgsProject.instance().mapLayersByName(layer_name)
    
    if not layers:
        raise ValueError(f"Layer '{layer_name}' not found!")
    
    layer = layers[0]
    
    # Detect layer type and pick field names accordingly
    field_names = [field.name() for field in layer.fields()]

    has_consensus = all(f in field_names for f in
                        ['DIST_HORIZ', 'DELTA_U', 'DELTA_E', 'DELTA_N'])
    has_baseline  = all(f in field_names for f in
                        ['baseline_2D_m', 'delta_h_abs_m'])

    if not has_consensus and not has_baseline:
        raise ValueError(
            "Layer missing required fields.\n"
            "Select the Consensus_A layer (after running Tab 3 — Inter-Receiver "
            "Analysis) or the Baseline_AB layer.")

    # Detect timestamp field (seconds of day)
    ts_field = None
    if "timestamp" in field_names:
        ts_field = "timestamp"
    elif "timestamp_sod" in field_names:
        ts_field = "timestamp_sod"

    # Extract data
    timestamps = []
    dist_horiz = []
    delta_u    = []   # signed on Consensus_A, absolute on Baseline_AB
    delta_e    = []   # only available on Consensus_A
    delta_n    = []   # only available on Consensus_A
    has_en     = has_consensus   # E/N components available only for Consensus_A

    for feat in layer.getFeatures():
        ts_val = feat[ts_field] if ts_field else None
        if has_consensus:
            dh = feat['DIST_HORIZ']
            du = feat['DELTA_U']
            de = feat['DELTA_E']
            dn = feat['DELTA_N']
            if None in (dh, du, de, dn):
                continue
            try:
                dist_horiz.append(float(dh))
                delta_u.append(float(du))
                delta_e.append(float(de))
                delta_n.append(float(dn))
                timestamps.append(float(ts_val) if ts_val is not None else None)
            except (ValueError, TypeError):
                continue
        else:  # Baseline_AB
            dh = feat['baseline_2D_m']
            du = feat['delta_h_abs_m']
            if None in (dh, du):
                continue
            try:
                dist_horiz.append(float(dh))
                delta_u.append(float(du))
                timestamps.append(float(ts_val) if ts_val is not None else None)
            except (ValueError, TypeError):
                continue

    if len(dist_horiz) == 0:
        raise ValueError("No valid data found in layer!")

    # Sort all arrays by timestamp (so time series reflect actual acquisition order)
    has_timestamps = bool(timestamps) and all(t is not None for t in timestamps)
    if has_timestamps:
        sort_idx   = np.argsort(timestamps)
        timestamps = np.array(timestamps)[sort_idx]
        dist_horiz = np.array(dist_horiz)[sort_idx]
        delta_u    = np.array(delta_u)[sort_idx]
        if has_en:
            delta_e = np.array(delta_e)[sort_idx]
            delta_n = np.array(delta_n)[sort_idx]
        x_ts        = timestamps
        x_label_ts  = "UTC Time (HH:MM:SS)"
        x_formatter = mticker.FuncFormatter(_sod_formatter)
    else:
        timestamps = np.arange(len(dist_horiz))
        dist_horiz = np.array(dist_horiz)
        delta_u    = np.array(delta_u)
        if has_en:
            delta_e = np.array(delta_e)
            delta_n = np.array(delta_n)
        x_ts        = timestamps
        x_label_ts  = "Epoch Index"
        x_formatter = None

    height_label = ("Height Difference (m)"
                    if has_consensus else "Height Difference |ΔU| (m)")
    
    plot_files = []
    
    # Plot 1: Horizontal distance histogram
    if plot_horiz_hist:
        plt.figure(figsize=(10, 6))
        plt.hist(dist_horiz, bins=50, color='steelblue', edgecolor='black', alpha=0.7)
        mean_horiz = np.mean(dist_horiz)
        median_horiz = np.median(dist_horiz)
        plt.axvline(mean_horiz, color='red', 
                    linestyle='--', linewidth=2, label=f'Mean')
        plt.axvline(median_horiz, color='orange', 
                    linestyle='--', linewidth=2, label=f'Median')
        plt.xlabel('Horizontal Distance (m)', fontsize=12)
        plt.ylabel('Frequency', fontsize=12)
        plt.title('Horizontal Distance Distribution\nLEFT vs RIGHT Consensus', fontsize=14)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        plot1_path = os.path.join(output_folder, 'plot1_horizontal_histogram.png')
        plt.savefig(plot1_path, dpi=300, bbox_inches='tight')
        plt.close()
        plot_files.append(plot1_path)
    
    # Plot 2: Height difference histogram
    if plot_height_hist:
        plt.figure(figsize=(10, 6))
        plt.hist(delta_u, bins=50, color='green', edgecolor='black', alpha=0.7)
        mean_du = np.mean(delta_u)
        median_du = np.median(delta_u)
        plt.axvline(mean_du, color='red',
                    linestyle='--', linewidth=2, label=f'Mean: {mean_du:.4f} m')
        plt.axvline(median_du, color='orange',
                    linestyle='--', linewidth=2, label=f'Median: {median_du:.4f} m')
        if has_consensus:
            plt.axvline(0, color='gray', linestyle='-', linewidth=1, label='Zero')
        plt.xlabel(height_label, fontsize=12)
        plt.ylabel('Frequency', fontsize=12)
        plt.title(f'{height_label} Distribution', fontsize=14)
        plt.legend()
        plt.grid(True, alpha=0.3)

        plot2_path = os.path.join(output_folder, 'plot2_height_histogram.png')
        plt.savefig(plot2_path, dpi=300, bbox_inches='tight')
        plt.close()
        plot_files.append(plot2_path)
    
    # Plot 3: Boxplot comparison
    if plot_boxplot:
        plt.figure(figsize=(10, 6))
        data_to_plot = [dist_horiz, [abs(d) for d in delta_u]]
        
        bp = plt.boxplot(data_to_plot, labels=['Horizontal', 'Height'], 
                         patch_artist=True, widths=0.6)
        
        # Color boxes
        colors = ['steelblue', 'green']
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        plt.ylabel('Distance / Difference (m)', fontsize=12)
        plt.title('Distribution Comparison\nLEFT vs RIGHT Consensus', fontsize=14)
        plt.grid(True, alpha=0.3, axis='y')
        
        plot3_path = os.path.join(output_folder, 'plot3_boxplot_comparison.png')
        plt.savefig(plot3_path, dpi=300, bbox_inches='tight')
        plt.close()
        plot_files.append(plot3_path)
    
    # Plot 4: Scatter E-N components (only if E/N fields are available)
    if plot_scatter_en and has_en:
        plt.figure(figsize=(10, 10))
        scatter = plt.scatter(delta_e, delta_n, c=dist_horiz,
                              cmap='viridis', s=5, alpha=0.6)
        plt.colorbar(scatter, label='Horizontal Distance (m)')
        plt.axhline(0, color='red', linestyle='--', linewidth=1, alpha=0.5)
        plt.axvline(0, color='red', linestyle='--', linewidth=1, alpha=0.5)
        plt.xlabel('ΔEast (m)', fontsize=12)
        plt.ylabel('ΔNorth (m)', fontsize=12)
        plt.title('Horizontal Components ΔE / ΔN', fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.axis('equal')

        plot4_path = os.path.join(output_folder, 'plot4_scatter_EN_components.png')
        plt.savefig(plot4_path, dpi=300, bbox_inches='tight')
        plt.close()
        plot_files.append(plot4_path)
    elif plot_scatter_en and not has_en:
        # Baseline_AB: scatter baseline_2D vs |delta_h| instead
        plt.figure(figsize=(10, 6))
        plt.scatter(dist_horiz, delta_u, s=5, alpha=0.5, color='steelblue')
        plt.xlabel('Horizontal Baseline (m)', fontsize=12)
        plt.ylabel(height_label, fontsize=12)
        plt.title('Horizontal Baseline vs Height Difference', fontsize=14)
        plt.grid(True, alpha=0.3)

        plot4_path = os.path.join(output_folder, 'plot4_scatter_horiz_vs_height.png')
        plt.savefig(plot4_path, dpi=300, bbox_inches='tight')
        plt.close()
        plot_files.append(plot4_path)
    
    # Plot 5: Time series horizontal
    if plot_timeseries:
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.scatter(x_ts, dist_horiz, color='steelblue', s=2, alpha=0.7)
        mean_horiz = np.mean(dist_horiz)
        std_horiz  = np.std(dist_horiz)
        ax.fill_between(x_ts,
                        mean_horiz - std_horiz,
                        mean_horiz + std_horiz,
                        color='red', alpha=0.2, label='±1 Std Dev')
        # Mean value shown in legend only — no line drawn
        ax.plot([], [], ' ', label=f'Mean: {mean_horiz:.4f} m')
        if x_formatter:
            ax.xaxis.set_major_formatter(x_formatter)
            plt.setp(ax.get_xticklabels(), rotation=30, ha='right')
        ax.set_xlabel(x_label_ts, fontsize=12)
        ax.set_ylabel('Horizontal Distance (m)', fontsize=12)
        ax.set_title('Horizontal Distance Over Time\nLEFT vs RIGHT Consensus', fontsize=14)
        ax.legend()
        ax.grid(True, alpha=0.3)

        plot5_path = os.path.join(output_folder, 'plot5_timeseries_horizontal.png')
        fig.savefig(plot5_path, dpi=300, bbox_inches='tight')
        plt.close(fig)
        plot_files.append(plot5_path)

    # Plot 6: Time series height
    if plot_timeseries_height:
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.scatter(x_ts, delta_u, color='green', s=2, alpha=0.7)
        mean_du = np.mean(delta_u)
        std_du  = np.std(delta_u)
        ax.axhline(0, color='gray', linestyle='-', linewidth=1, label='Zero')
        ax.fill_between(x_ts,
                        mean_du - std_du,
                        mean_du + std_du,
                        color='red', alpha=0.2, label='±1 Std Dev')
        # Mean value shown in legend only — no line drawn
        ax.plot([], [], ' ', label=f'Mean: {mean_du:.4f} m')
        if x_formatter:
            ax.xaxis.set_major_formatter(x_formatter)
            plt.setp(ax.get_xticklabels(), rotation=30, ha='right')
        ax.set_xlabel(x_label_ts, fontsize=12)
        ax.set_ylabel(height_label, fontsize=12)
        ax.set_title(f'{height_label} Over Time', fontsize=14)
        ax.legend()
        ax.grid(True, alpha=0.3)

        plot6_path = os.path.join(output_folder, 'plot6_timeseries_height.png')
        fig.savefig(plot6_path, dpi=300, bbox_inches='tight')
        plt.close(fig)
        plot_files.append(plot6_path)
    
    return plot_files