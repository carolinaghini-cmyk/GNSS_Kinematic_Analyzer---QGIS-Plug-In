# -*- coding: utf-8 -*-
"""
Inter-Receiver Analysis Module
================================
Computes the ENU vector between two consensus layers (Antenna A and
Antenna B) epoch by epoch, and writes results back to layer A.

Exposes:
  analyze_inter_receiver()  – adds ENU fields to Consensus_A layer
  export_antenna_csv()      – writes antenna_A.txt or antenna_B.txt
  export_baseline_csv()     – writes baseline_AB.txt

Optimisations vs previous version
───────────────────────────────────
• analyze_inter_receiver: collects all attribute changes into a dict
  and calls dataProvider().changeAttributeValues() ONCE (batch write)
  instead of one changeAttributeValue() call per epoch per field.
• export_*: extract all fields in a single getFeatures() pass into
  numpy arrays; no per-epoch Python math.
• Vectorised ENU computation throughout.
"""

import math
import numpy as np
import os
import pandas as pd
from qgis.core import (QgsProject, QgsField, QgsVectorLayer,
                       QgsFeature, QgsGeometry, QgsPointXY)
from qgis.PyQt.QtCore import QVariant


def _sod_to_utc(sod):
    """Convert seconds-of-day (float) to UTC time string HH:MM:SS.fff"""
    sod = float(sod)
    h = int(sod // 3600)
    m = int((sod % 3600) // 60)
    s = sod % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}"


_sod_to_utc_vec = np.vectorize(_sod_to_utc)

_a  = 6378137.0
_e2 = 0.00669437999014


# ── coordinate helpers ────────────────────────────────────────────────────────

def _ecef_to_geodetic_scalar(X, Y, Z):
    """Iterative Bowring method (scalar, used only for centroid)."""
    lon = math.atan2(Y, X)
    p   = math.sqrt(X*X + Y*Y)
    lat = math.atan2(Z, p * (1 - _e2))
    for _ in range(5):
        sl = math.sin(lat)
        N  = _a / math.sqrt(1 - _e2 * sl*sl)
        h  = p / math.cos(lat) - N
        lat = math.atan2(Z, p * (1 - _e2 * N / (N + h)))
    return lat, lon


def _lla_to_ecef_vec(lat_deg, lon_deg, h):
    lat = np.radians(lat_deg); lon = np.radians(lon_deg)
    N   = _a / np.sqrt(1.0 - _e2 * np.sin(lat)**2)
    X   = (N + h) * np.cos(lat) * np.cos(lon)
    Y   = (N + h) * np.cos(lat) * np.sin(lon)
    Z   = (N * (1.0 - _e2) + h) * np.sin(lat)
    return X, Y, Z


def _ecef_to_enu_vec(Xp, Yp, Zp, Xr, Yr, Zr, lat_r, lon_r):
    """Vectorised ECEF-to-ENU around reference point (lat_r, lon_r)."""
    sl = np.sin(lat_r); cl = np.cos(lat_r)
    sn = np.sin(lon_r); cn = np.cos(lon_r)
    dX = Xp - Xr; dY = Yp - Yr; dZ = Zp - Zr
    E = -sn*dX + cn*dY
    N = -sl*cn*dX - sl*sn*dY + cl*dZ
    U =  cl*cn*dX + cl*sn*dY + sl*dZ
    return E, N, U


# ── stats helper ──────────────────────────────────────────────────────────────

def _stats(arr):
    if len(arr) == 0:
        return {}
    s = np.sort(arr)
    return {
        "mean":   float(np.mean(arr)),
        "median": float(s[len(s)//2]),
        "std":    float(np.std(arr)),
        "rms":    float(np.sqrt(np.mean(arr**2))),
        "min":    float(s[0]),
        "max":    float(s[-1]),
        "q1":     float(s[int(len(s)*0.25)]),
        "q3":     float(s[int(len(s)*0.75)]),
        "range":  float(s[-1] - s[0]),
    }


# ── layer data loader ─────────────────────────────────────────────────────────

def _load_fields(layer, *field_names):
    """
    Load requested fields from all features into numpy arrays.
    Returns (fids, ts_arr, arrays...) where fids is the list of feature ids.
    Missing, NULL, NaN and infinite values are excluded.
    """
    fids = []; rows = []
    fidxs = [layer.fields().indexFromName(n) for n in field_names]

    for feat in layer.getFeatures():
        vals = [feat[fi] for fi in fidxs]
        # Skip NULL / None
        if None in vals:
            continue
        # Skip empty strings
        if any(isinstance(v, str) and v.strip() == "" for v in vals):
            continue
        try:
            fvals = [float(v) for v in vals]
        except (TypeError, ValueError):
            continue
        # Skip NaN or infinite values (blown-up outliers)
        if any(not math.isfinite(v) for v in fvals):
            continue
        fids.append(feat.id())
        rows.append(fvals)

    if not rows:
        return [np.array([])] * (len(field_names) + 1)

    arr = np.array(rows, dtype=float)
    return [np.array(fids, dtype=int)] + [arr[:, i] for i in range(arr.shape[1])]


# ── analyse inter-receiver ────────────────────────────────────────────────────

def analyze_inter_receiver(layer_a_name, layer_b_name, baseline_ref, baseline_ref_up,
                           color_field="sigma_plan_m"):
    """
    Compute ENU vector between Consensus_A and Consensus_B.
    Writes DIST_HORIZ, DIFF_HEIGHT, DELTA_E, DELTA_N, DELTA_U to layer A.

    The ENU rotation matrix is recomputed at every epoch using the
    Antenna A consensus position as the reference point. This is the
    geodetically rigorous formulation and is valid regardless of the
    trajectory extent.
    """
    def _get(name):
        lys = QgsProject.instance().mapLayersByName(name)
        if not lys:
            raise ValueError(f"Layer '{name}' not found.")
        return lys[0]

    lay_a = _get(layer_a_name)
    lay_b = _get(layer_b_name)

    # Add missing fields to A
    existing = {f.name() for f in lay_a.fields()}
    new_fields = [QgsField(n, QVariant.Double)
                  for n in ("DIST_HORIZ","DIFF_HEIGHT","DELTA_E","DELTA_N","DELTA_U")
                  if n not in existing]
    if new_fields:
        lay_a.dataProvider().addAttributes(new_fields)
        lay_a.updateFields()

    # Field indices on A
    flds_a = lay_a.fields()
    idx_dh  = flds_a.indexFromName("DIST_HORIZ")
    idx_dhi = flds_a.indexFromName("DIFF_HEIGHT")
    idx_de  = flds_a.indexFromName("DELTA_E")
    idx_dn  = flds_a.indexFromName("DELTA_N")
    idx_du  = flds_a.indexFromName("DELTA_U")

    # Load B into a timestamp → (Xe, Ye, Ze) index
    b_idx = {}
    for feat in lay_b.getFeatures():
        ts = feat["timestamp"]
        Xb = feat["X_ECEF"]; Yb = feat["Y_ECEF"]; Zb = feat["Z_ECEF"]
        if None in (ts, Xb, Yb, Zb):
            continue
        b_idx[float(ts)] = (float(Xb), float(Yb), float(Zb))

    # Load A entirely
    has_dt_utc = "datetime_utc" in {f.name() for f in lay_a.fields()}
    fid_list = []; ts_a = []; Xa_l = []; Ya_l = []; Za_l = []; dt_utc_a = []
    for feat in lay_a.getFeatures():
        ts = feat["timestamp"]
        Xa = feat["X_ECEF"]; Ya = feat["Y_ECEF"]; Za = feat["Z_ECEF"]
        if None in (ts, Xa, Ya, Za):
            continue
        ts_f = float(ts)
        if ts_f not in b_idx:
            continue
        fid_list.append(feat.id())
        ts_a.append(ts_f)
        Xa_l.append(float(Xa)); Ya_l.append(float(Ya)); Za_l.append(float(Za))
        dt_utc_a.append(feat["datetime_utc"] if has_dt_utc else None)

    if not fid_list:
        raise ValueError("No common epochs between the two layers.")

    Xa_a = np.array(Xa_l); Ya_a = np.array(Ya_l); Za_a = np.array(Za_l)
    Xb_a = np.array([b_idx[t][0] for t in ts_a])
    Yb_a = np.array([b_idx[t][1] for t in ts_a])
    Zb_a = np.array([b_idx[t][2] for t in ts_a])

    # Centroid kept for reference / potential future use
    Xm = (Xa_a + Xb_a) / 2.0
    Ym = (Ya_a + Yb_a) / 2.0
    Zm = (Za_a + Zb_a) / 2.0

    # Per-epoch ENU rotation using Antenna A as reference (rigorous).
    lat_r_arr = np.empty_like(Xa_a)
    lon_r_arr = np.empty_like(Xa_a)
    for i in range(Xa_a.size):
        lat_r_arr[i], lon_r_arr[i] = _ecef_to_geodetic_scalar(
            float(Xa_a[i]), float(Ya_a[i]), float(Za_a[i]))

    Ea, Na, Ua = _ecef_to_enu_vec(Xa_a, Ya_a, Za_a,
                                  Xa_a, Ya_a, Za_a,
                                  lat_r_arr, lon_r_arr)
    Eb, Nb, Ub = _ecef_to_enu_vec(Xb_a, Yb_a, Zb_a,
                                  Xa_a, Ya_a, Za_a,
                                  lat_r_arr, lon_r_arr)

    dE = Eb - Ea; dN = Nb - Na; dU = Ub - Ua
    dH = np.sqrt(dE**2 + dN**2)

    # Build bulk attribute-change dict  {fid: {field_idx: value, ...}}
    attr_map = {}
    for i, fid in enumerate(fid_list):
        attr_map[fid] = {
            idx_dh:  round(float(dH[i]), 5),
            idx_dhi: round(float(dU[i]), 5),
            idx_de:  round(float(dE[i]), 5),
            idx_dn:  round(float(dN[i]), 5),
            idx_du:  round(float(dU[i]), 5),
        }

    lay_a.dataProvider().changeAttributeValues(attr_map)
    lay_a.triggerRepaint()

    # ── Build Baseline_AB memory layer ────────────────────────────────────────
    # Midpoint lat/lon from ECEF
    Xm = (Xa_a + Xb_a) / 2.0
    Ym = (Ya_a + Yb_a) / 2.0
    Zm = (Za_a + Zb_a) / 2.0
    lat_mid = np.degrees(np.arctan2(Zm, np.sqrt(Xm**2 + Ym**2) * (1 - _e2)))
    lon_mid = np.degrees(np.arctan2(Ym, Xm))

    # Load A RS quality fields and height
    flds_a_all = {f.name(): f for f in lay_a.fields()}
    has_rms = ("RMS2D_rs" in flds_a_all and "RMSUp_rs" in flds_a_all)
    fid_to_i   = {fid: i for i, fid in enumerate(fid_list)}
    h_mid_arr   = np.zeros(len(fid_list))
    rms2d_a_arr = np.zeros(len(fid_list))
    rmsu_a_arr  = np.zeros(len(fid_list))
    rms2d_b_arr = np.zeros(len(fid_list))
    rmsu_b_arr  = np.zeros(len(fid_list))

    for feat in lay_a.getFeatures():
        fid = feat.id()
        if fid not in fid_to_i:
            continue
        i = fid_to_i[fid]
        h_a_val = feat["height"]
        h_mid_arr[i] = float(h_a_val) if h_a_val is not None else 0.0
        if has_rms:
            v2 = feat["RMS2D_rs"]; vu = feat["RMSUp_rs"]
            rms2d_a_arr[i] = float(v2) if v2 is not None else 0.0
            rmsu_a_arr[i]  = float(vu) if vu is not None else 0.0

    # Load B RS quality fields
    lys_b = QgsProject.instance().mapLayersByName(layer_b_name)
    if lys_b:
        lay_b_ref = lys_b[0]
        flds_b_all = {f.name() for f in lay_b_ref.fields()}
        has_rms_b = ("RMS2D_rs" in flds_b_all and "RMSUp_rs" in flds_b_all)
        b_ts_rs = {}
        for feat in lay_b_ref.getFeatures():
            ts = feat["timestamp"]
            if ts is None:
                continue
            v2 = feat["RMS2D_rs"] if has_rms_b else None
            vu = feat["RMSUp_rs"] if has_rms_b else None
            b_ts_rs[float(ts)] = (
                float(v2) if v2 is not None else 0.0,
                float(vu) if vu is not None else 0.0,
            )
        for i, ts in enumerate(ts_a):
            if ts in b_ts_rs:
                rms2d_b_arr[i], rmsu_b_arr[i] = b_ts_rs[ts]

    # Combined sigma:
    #   sigma_plan = sqrt(RMS2D_rx1^2 + RMS2D_rx2^2 + baseline_2D^2)
    #   sigma_vert = sqrt(RMSUp_rx1^2 + RMSUp_rx2^2 + |dU|^2)
    n2d = dH
    delta_h_abs = np.abs(dU)
    # Residuals against reference baseline
    err2D = np.abs(dH - baseline_ref)
    errUp = np.abs(dU - baseline_ref_up)

    # Final propagated uncertainty
    sigma_plan = np.sqrt(
        rms2d_a_arr**2 +
        rms2d_b_arr**2 +
        err2D**2
    )

    sigma_vert = np.sqrt(
        rmsu_a_arr**2 +
        rmsu_b_arr**2 +
        errUp**2
    )

    # Determine which named layer to (re)create based on the chosen sigma field.
    # Only that layer is removed and recreated; the other is left untouched.
    # Also clean up the old generic "Baseline_AB" and "Baseline_AB_vert" names
    # from previous plugin versions.
    layer_out_name = "Baseline_AB_Plan" if color_field == "sigma_plan_m" else "Baseline_AB_Vert"
    for lname in (layer_out_name, "Baseline_AB", "Baseline_AB_vert"):
        for old in QgsProject.instance().mapLayersByName(lname):
            QgsProject.instance().removeMapLayer(old.id())

    crs_str  = lay_a.crs().authid()
    bl_layer = QgsVectorLayer(f"Point?crs={crs_str}", layer_out_name, "memory")
    bl_prov  = bl_layer.dataProvider()
    bl_prov.addAttributes([
        QgsField("timestamp_utc",   QVariant.String),
        QgsField("timestamp_sod",   QVariant.Double),
        QgsField("lat_mean_deg",    QVariant.Double),
        QgsField("lon_mean_deg",    QVariant.Double),
        QgsField("h_mean_m",        QVariant.Double),
        QgsField("baseline_2D_m",   QVariant.Double),
        QgsField("delta_h_abs_m",   QVariant.Double),
        QgsField("sigma_plan_m",    QVariant.Double),
        QgsField("sigma_vert_m",    QVariant.Double),
        QgsField("color_class",     QVariant.Int),
    ])
    bl_layer.updateFields()

    def _color_class(val_m):
        """Default classify into 1..5 colour classes."""
        v = abs(val_m)
        if v <= 0.05:   return 1
        elif v <= 0.20: return 2
        elif v <= 0.50: return 3
        elif v <= 1.00: return 4
        else:           return 5

    bl_feats = []
    for i in range(len(fid_list)):
        feat = QgsFeature(bl_layer.fields())
        feat["timestamp_utc"]    = dt_utc_a[i] if dt_utc_a[i] else _sod_to_utc(ts_a[i])
        feat["timestamp_sod"]    = round(float(ts_a[i]), 6)
        feat["lat_mean_deg"]     = round(float(lat_mid[i]), 8)
        feat["lon_mean_deg"]     = round(float(lon_mid[i]), 8)
        feat["h_mean_m"]         = round(float(h_mid_arr[i]), 3)
        feat["baseline_2D_m"]    = round(float(n2d[i]), 5)
        feat["delta_h_abs_m"]    = round(float(delta_h_abs[i]), 5)
        feat["sigma_plan_m"]     = round(float(sigma_plan[i]), 5)
        feat["sigma_vert_m"]     = round(float(sigma_vert[i]), 5)
        feat["color_class"]      = _color_class(float(sigma_plan[i]) if color_field == "sigma_plan_m"
                                                 else float(sigma_vert[i]))
        feat.setGeometry(QgsGeometry.fromPointXY(
            QgsPointXY(float(lon_mid[i]), float(lat_mid[i]))))
        bl_feats.append(feat)

    bl_prov.addFeatures(bl_feats)
    bl_layer.updateExtents()
    QgsProject.instance().addMapLayer(bl_layer)

    return {
        "matched":      len(fid_list),
        "mean_horiz":   float(np.mean(dH)),
        "mean_height":  float(np.mean(dU)),
        "stats_horiz":  _stats(dH),
        "stats_height": _stats(dU),
    }


# ── export antenna .txt ───────────────────────────────────────────────────────

def export_antenna_csv(consensus_layer_name, output_path):
    """
    Write antenna_X.txt from a consensus layer.
    Reads RS fields written by consensus.py (Tab 2).
    Returns stats dict.
    """
    lys = QgsProject.instance().mapLayersByName(consensus_layer_name)
    if not lys:
        raise ValueError(f"Layer '{consensus_layer_name}' not found.")
    layer = lys[0]

    required = ("timestamp","latitude","longitude","height",
                "dE_rs","dN_rs","dU_rs","RMS2D_rs","RMSUp_rs")
    missing = [f for f in required if layer.fields().indexFromName(f) < 0]
    if missing:
        raise ValueError(
            f"Missing fields in layer '{consensus_layer_name}': {missing}\n"
            "Please run RS Consensus (Tab 2) first.")

    # Single-pass extraction
    result = _load_fields(layer, *required)
    if len(result[1]) == 0:
        raise ValueError("No valid data in layer.")
    _, ts, lat, lon, h, dE, dN, dU, r2, rU = result

    df = pd.DataFrame({
        "timestamp_utc": _sod_to_utc_vec(ts),
        "lat_deg":    np.round(lat, 8),
        "lon_deg":    np.round(lon, 8),
        "h_m":        np.round(h,   3),
        "dE_rs_m":    np.round(dE,  3),
        "dN_rs_m":    np.round(dN,  3),
        "dU_rs_m":    np.round(dU,  3),
        "RMS2D_m":    np.round(r2,  3),
        "RMSUp_m":    np.round(rU,  3),
    })
    df.to_csv(output_path, index=False)

    def _s(arr):
        return {"mean": float(np.mean(arr)), "std": float(np.std(arr)),
                "rms":  float(np.sqrt(np.mean(arr**2))),
                "max":  float(np.max(np.abs(arr)))}

    return {"n_epochs": len(ts),
            "dN": _s(dN), "dE": _s(dE), "dU": _s(dU)}


# ── export baseline .txt ──────────────────────────────────────────────────────

def export_baseline_csv(layer_a_name, layer_b_name,
                        output_path, baseline_ref, baseline_ref_up):
    """
    Write baseline_AB.txt from the Baseline_AB memory layer created by
    analyze_inter_receiver(), adding err2D_vs_ref_m and errUp_vs_ref_m
    columns computed against the supplied reference values.

    Also writes those two error fields back into the Baseline_AB layer
    so they are immediately inspectable in QGIS.

    Returns stats dict.
    """
    bl = None
    for lname in ("Baseline_AB_Plan", "Baseline_AB_Vert", "Baseline_AB"):
        lys = QgsProject.instance().mapLayersByName(lname)
        if lys:
            bl = lys[0]
            break
    if bl is None:
        raise ValueError(
            "No baseline layer found (Baseline_AB_Plan or Baseline_AB_Vert). "
            "Please run Inter-Receiver Analysis (Tab 3) first.")

    required = ("timestamp_sod", "lat_mean_deg", "lon_mean_deg",
                "h_mean_m", "baseline_2D_m", "delta_h_abs_m",
                "sigma_plan_m", "sigma_vert_m")
    missing = [f for f in required if bl.fields().indexFromName(f) < 0]
    if missing:
        raise ValueError(f"Missing fields in {bl.name()}: {missing}")

    res = _load_fields(bl, *required)
    if len(res[1]) == 0:
        raise ValueError("No valid data in Baseline_AB layer.")
    _, ts, lat_m, lon_m, h_m, n2d, dh_abs, sig_plan, sig_vert = res

    df = pd.DataFrame({
        "timestamp_utc":    _sod_to_utc_vec(ts),
        "lat_mean_deg":     np.round(lat_m,    8),
        "lon_mean_deg":     np.round(lon_m,    8),
        "h_mean_m":         np.round(h_m,      3),
        "baseline_2D_m":    np.round(n2d,      5),
        "delta_h_abs_m":    np.round(dh_abs,   5),
        "sigma_plan_m":     np.round(sig_plan, 5),
        "sigma_vert_m":     np.round(sig_vert, 5),
    })
    df.to_csv(output_path, index=False)

    return {
        "n_epochs":         len(ts),
        "sigma_plan_mean":  float(np.mean(sig_plan)),
        "sigma_plan_rms":   float(np.sqrt(np.mean(sig_plan**2))),
        "sigma_vert_mean":  float(np.mean(sig_vert)),
        "sigma_vert_rms":   float(np.sqrt(np.mean(sig_vert**2))),
        "baseline_ref_m":   baseline_ref,
    }
