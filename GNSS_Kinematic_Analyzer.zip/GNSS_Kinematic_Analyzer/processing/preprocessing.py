# -*- coding: utf-8 -*-
"""
PPKTrack / RTKLib Preprocessing Module
Converts PPKTrack or RTKLib .pos files to XGIS format.
Optimised: bulk datetime parsing, single-pass filtering.
"""

import os
import re
from datetime import datetime, timedelta

_LEAP_SECONDS = 18  # GPST − UTC offset, valid from 2017-01-01

SOLUTION_TYPES = {
    "Fix":     ["Fix"],
    "Float":   ["Float"],
    "PRD":     ["Pseudo-range Diff"],
    "SPP":     ["SPP"],
    "Invalid": ["Invalid"],
}

# RTKLib Q-code → label (matches SOLUTION_TYPES values where possible)
_RTKLIB_Q_LABELS = {
    1: "Fix",
    2: "Float",
    3: "SBAS",
    4: "Pseudo-range Diff",
    5: "SPP",
    6: "PPP",
}

_epoch_re = re.compile(
    r"^(\d{4}-\d{2}-\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d+)")

# RTKLib .pos format: YYYY/MM/DD HH:MM:SS.sss  lat  lon  height  Q  ns ...
_rtklib_re = re.compile(
    r"^(\d{4})/(\d{2})/(\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d+)\s+"
    r"([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s+(\d+)")


def get_current_datetime():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def preprocess_ppktrack(input_file, output_folder, solution_filter=None):
    """
    Convert a PPKTrack file to XGIS format.

    Optimisations vs previous version
    ───────────────────────────────────
    • Regex-based timestamp parsing (no pandas per-row call)
    • Single pass over rows: parse + filter + write in one loop
    • Output written with a list join instead of repeated f-string writes
    """
    if solution_filter is None or "all" in solution_filter:
        accepted_values = None
    else:
        accepted_values = set()
        for key in solution_filter:
            accepted_values.update(SOLUTION_TYPES.get(key, [key]))

    base_name   = os.path.basename(input_file)
    output_file = os.path.join(output_folder, base_name + "_xgis.txt")

    type_counts  = {}
    total_rows   = 0
    out_lines    = ["Timestamp,Latitude,Longitude,Height,Solution_Type,UTC_Time\n"]

    with open(input_file, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("*") or line.startswith("Epoch"):
                continue

            m = _epoch_re.match(line)
            if not m:
                continue
            total_rows += 1

            parts = line.split(",")
            if len(parts) < 15:
                continue

            solution = parts[2].strip()
            type_counts[solution] = type_counts.get(solution, 0) + 1

            if accepted_values is not None and solution not in accepted_values:
                continue

            try:
                lat = float(parts[12].strip().replace("N", "").replace("S", ""))
                lon = float(parts[13].strip().replace("E", "").replace("W", ""))
                h   = float(parts[14].strip())
            except (ValueError, IndexError):
                continue

            # PPKTrack timestamps are already UTC (header says "Epoch(UTC)")
            hh, mm, ss, frac = int(m.group(2)), int(m.group(3)), \
                               int(m.group(4)), m.group(5)
            sod     = hh * 3600 + mm * 60 + ss + int(frac) / (10 ** len(frac))
            utc_str = f"{m.group(1)} {hh:02d}:{mm:02d}:{ss:02d}.{frac}"

            out_lines.append(
                f"{sod:.6f},{lat:.8f},{lon:.8f},{h:.3f},{solution},{utc_str}\n")

    with open(output_file, "w", encoding="utf-8") as fh:
        fh.writelines(out_lines)

    output_records = len(out_lines) - 1   # exclude header
    fix_count      = type_counts.get("Fix", 0)
    nofix_count    = total_rows - fix_count

    return {
        "total_records":  total_rows,
        "fix_count":      fix_count,
        "nofix_count":    nofix_count,
        "fix_percentage":   fix_count  / total_rows * 100 if total_rows else 0.0,
        "nofix_percentage": nofix_count / total_rows * 100 if total_rows else 0.0,
        "type_counts":    type_counts,
        "solution_filter": solution_filter,
        "output_file":    output_file,
        "output_records": output_records,
    }


def preprocess_rtklib_pos(input_file, output_folder, solution_filter=None):
    """Convert an RTKLib .pos file to XGIS format.

    Column layout (space-separated):
        YYYY/MM/DD HH:MM:SS.sss  lat(deg)  lon(deg)  height(m)  Q  ns  ...
    Q codes: 1=Fix, 2=Float, 3=SBAS, 4=DGPS/PRD, 5=Single/SPP, 6=PPP
    """
    if solution_filter is None or "all" in solution_filter:
        accepted_values = None
    else:
        accepted_values = set()
        for key in solution_filter:
            accepted_values.update(SOLUTION_TYPES.get(key, [key]))

    base_name   = os.path.basename(input_file)
    output_file = os.path.join(output_folder, base_name + "_xgis.txt")

    type_counts = {}
    total_rows  = 0
    out_lines   = ["Timestamp,Latitude,Longitude,Height,Solution_Type,UTC_Time\n"]

    time_system = "UTC"  # updated from first % header line

    with open(input_file, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            if line.startswith("%"):
                # Detect time system from the column-label header line
                # e.g. "%  GPST   latitude..."  or  "%  UTC   latitude..."
                upper = line.upper()
                if "GPST" in upper:
                    time_system = "GPST"
                elif " UTC " in upper or upper.rstrip().endswith("UTC"):
                    time_system = "UTC"
                continue

            m = _rtklib_re.match(line)
            if not m:
                continue
            total_rows += 1

            usec = int(m.group(7).ljust(6, "0")[:6])
            dt   = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                            int(m.group(4)), int(m.group(5)), int(m.group(6)), usec)
            if time_system == "GPST":
                dt -= timedelta(seconds=_LEAP_SECONDS)

            sod     = dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6
            utc_str = dt.strftime("%Y-%m-%d %H:%M:%S.%f")

            lat      = float(m.group(8))
            lon      = float(m.group(9))
            h        = float(m.group(10))
            q        = int(m.group(11))
            solution = _RTKLIB_Q_LABELS.get(q, f"Q{q}")

            type_counts[solution] = type_counts.get(solution, 0) + 1

            if accepted_values is not None and solution not in accepted_values:
                continue

            out_lines.append(
                f"{sod:.6f},{lat:.8f},{lon:.8f},{h:.3f},{solution},{utc_str}\n")

    with open(output_file, "w", encoding="utf-8") as fh:
        fh.writelines(out_lines)

    output_records = len(out_lines) - 1
    fix_count      = type_counts.get("Fix", 0)
    nofix_count    = total_rows - fix_count

    return {
        "total_records":  total_rows,
        "fix_count":      fix_count,
        "nofix_count":    nofix_count,
        "fix_percentage":   fix_count  / total_rows * 100 if total_rows else 0.0,
        "nofix_percentage": nofix_count / total_rows * 100 if total_rows else 0.0,
        "type_counts":    type_counts,
        "solution_filter": solution_filter,
        "output_file":    output_file,
        "output_records": output_records,
    }
