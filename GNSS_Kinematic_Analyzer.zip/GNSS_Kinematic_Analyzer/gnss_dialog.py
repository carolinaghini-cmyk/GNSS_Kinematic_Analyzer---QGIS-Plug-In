# -*- coding: utf-8 -*-
import os
import numpy as np
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QMessageBox
from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QPixmap, QColor
from qgis.core import (QgsProject, QgsVectorLayer, QgsMessageLog, Qgis,
                       QgsCategorizedSymbolRenderer, QgsRendererCategory,
                       QgsMarkerSymbol, QgsSymbol)

from .output_legend_dialog import OutputLegendDialog
from .processing import preprocessing
from .processing import consensus
from .processing import inter_receiver
from .processing import static_precision
from .processing import visualization

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'gnss_dialog_base.ui'))

# Colour classification palette for baseline_2D error
_CLASS_COLORS = {
    1: ("#2ecc71", "0–5 cm"),
    2: ("#f1c40f", "5–20 cm"),
    3: ("#e67e22", "20–50 cm"),
    4: ("#e74c3c", "50–100 cm"),
    5: ("#8e44ad", ">100 cm"),
}


class GNSSDialog(QDialog, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self._ir_done = False
        self._cons_done = False
        self._loadLogo()
        self._connectSignals()
        self._populateCombos()

    def _loadLogo(self):
        """Load Sapienza logo into the UI label."""
        logo_path = os.path.join(os.path.dirname(__file__), "LaSapienza.jpg")
        if os.path.exists(logo_path):
            pix = QPixmap(logo_path)
            self.labelSapienzaLogo.setPixmap(
                pix.scaled(240, 70,
                           aspectRatioMode=1,      # Qt::KeepAspectRatio
                           transformMode=1))        # Qt::SmoothTransformation

    # =========================================================================
    # SIGNAL WIRING
    # =========================================================================

    def _connectSignals(self):
        # Tab 1
        self.btnBrowseAV1.clicked.connect(lambda: self._browseFile(self.lineFileAV1))
        self.btnBrowseBV1.clicked.connect(lambda: self._browseFile(self.lineFileBV1))
        self.btnBrowseAV2.clicked.connect(lambda: self._browseFile(self.lineFileAV2))
        self.btnBrowseBV2.clicked.connect(lambda: self._browseFile(self.lineFileBV2))
        self.btnBrowseOutput.clicked.connect(lambda: self._browseFolder(self.lineOutputFolder))
        self.btnRunPreprocessing.clicked.connect(self.runPreprocessing)
        self.btnOutputLegend.clicked.connect(self.showOutputLegend)
        self.checkSolAll.stateChanged.connect(self._onSolAllChanged)

        # Tab 2
        self.btnBrowseReportFolder.clicked.connect(lambda: self._browseFolder(self.lineReportFolder))
        self.btnBrowseAntOutput.clicked.connect(lambda: self._browseFolder(self.lineAntOutputFolder))
        self.btnRunVRSConsensus.clicked.connect(self.runVRSConsensus)
        self.btnExportAntennaA.clicked.connect(self.exportAntennaA)
        self.btnExportAntennaB.clicked.connect(self.exportAntennaB)
        self.btnInputFormatHelp.clicked.connect(self.showInputFormat)

        # Tab 3
        self.btnBrowseBaselineOutput.clicked.connect(
            lambda: self._browseFolder(self.lineBaselineOutputFolder))
        self.btnRunInterReceiver.clicked.connect(self.runInterReceiver)
        self.btnExportBaseline.clicked.connect(self.exportBaseline)
        self.gbColorClass.toggled.connect(self._applyColorClassification)

        # Tab 4
        self.btnRunStaticPrecision.clicked.connect(self.runStaticPrecision)
        self.btnExportStaticReport.clicked.connect(self.exportStaticReport)

        # Tab 5
        self.btnGeneratePlots.clicked.connect(self.runVisualization)
        self.btnShowStats.clicked.connect(self.showStatistics)

    # =========================================================================
    # HELPERS
    # =========================================================================

    def _browseFile(self, line_edit):
        fn, _ = QFileDialog.getOpenFileName(
            self, "Select PPKTrack / RTKLib file",
            line_edit.text() or "",
            "PPKTrack / RTKLib Files (*.txt *.pos);;All Files (*)")
        if fn:
            line_edit.setText(fn)

    def _browseFolder(self, line_edit):
        folder = QFileDialog.getExistingDirectory(
            self, "Select folder", line_edit.text() or "")
        if folder:
            line_edit.setText(folder)

    def _getSolutionFilter(self):
        if self.checkSolAll.isChecked():
            return ["all"]
        sel = []
        if self.checkSolFix.isChecked():   sel.append("Fix")
        if self.checkSolFloat.isChecked(): sel.append("Float")
        if not sel:
            QMessageBox.warning(self, "No filter selected",
                                "Please select at least one solution type.")
            return None
        return sel

    def _onSolAllChanged(self, state):
        locked = bool(state)
        for cb in (self.checkSolFix, self.checkSolFloat):
            cb.setEnabled(not locked)

    def _getInputFiles(self):
        paths = {
            "file_a_vrs1": self.lineFileAV1.text().strip(),
            "file_b_vrs1": self.lineFileBV1.text().strip(),
            "file_a_vrs2": self.lineFileAV2.text().strip(),
            "file_b_vrs2": self.lineFileBV2.text().strip(),
        }
        labels = {
            "file_a_vrs1": "Antenna A / RS 1",
            "file_b_vrs1": "Antenna B / RS 1",
            "file_a_vrs2": "Antenna A / RS 2",
            "file_b_vrs2": "Antenna B / RS 2",
        }
        missing = [labels[k] for k, v in paths.items() if not v]
        if missing:
            QMessageBox.warning(self, "Missing files",
                "Enter all four files in the Preprocessing tab:\n"
                + "\n".join(f"  \u2022 {m}" for m in missing))
            return None
        not_found = [labels[k] for k, v in paths.items()
                     if v and not os.path.isfile(v)]
        if not_found:
            QMessageBox.warning(self, "Files not found",
                "\n".join(f"  \u2022 {m}" for m in not_found))
            return None
        return paths

    def _populateCombos(self):
        names = [l.name() for l in QgsProject.instance().mapLayers().values()]

        # Tab 2 — 4 combo con suggerimento automatico per ruolo
        role_hints = {
            self.comboConsAV1: "Ant_A_RS1",
            self.comboConsAV2: "Ant_A_RS2",
            self.comboConsBV1: "Ant_B_RS1",
            self.comboConsBV2: "Ant_B_RS2",
        }
        for combo, hint in role_hints.items():
            combo.clear()
            combo.addItems(names)
            if hint in names:
                combo.setCurrentText(hint)

        # Tab 3
        for combo, hint in ((self.comboLayerA, "Consensus_A"),
                            (self.comboLayerB, "Consensus_B")):
            combo.clear()
            combo.addItems(names)
            if hint in names:
                combo.setCurrentText(hint)

        # Tab 4 — all project layers; auto-select first consensus layer found
        self.comboVehicleLayer.clear()
        self.comboVehicleLayer.addItems(names)
        for hint in ("Consensus_A", "Consensus_B", "Baseline_AB"):
            if hint in names:
                self.comboVehicleLayer.setCurrentText(hint)
                break

        # Tab 5 — all layers, prefer Baseline_AB then Consensus_A
        self.comboAnalysisLayer.clear()
        self.comboAnalysisLayer.addItems(names)
        for hint in ("Baseline_AB_Plan", "Baseline_AB_Vert", "Baseline_AB", "Consensus_A"):
            if hint in names:
                self.comboAnalysisLayer.setCurrentText(hint)
                break

    def _requireFolder(self, line_edit, label):
        folder = line_edit.text().strip()
        if not folder:
            # fallback alla cartella del Preprocessing
            folder = self.lineOutputFolder.text().strip()
            if folder:
                line_edit.setText(folder)
        if not folder:
            QMessageBox.warning(self, "Missing folder",
                                f"Please select a folder for {label}.")
            return None
        if not os.path.isdir(folder):
            QMessageBox.warning(self, "Folder not found",
                                f"The folder does not exist:\n{folder}")
            return None
        return folder

    # =========================================================================
    # TAB 1 — PREPROCESSING
    # =========================================================================

    def runPreprocessing(self):
        files = self._getInputFiles()
        if files is None:
            return

        out_folder = self.lineOutputFolder.text().strip()
        if not out_folder or not os.path.isdir(out_folder):
            QMessageBox.warning(self, "Missing folder",
                                "Please select a valid output folder.")
            return

        sol_filter = self._getSolutionFilter()
        if sol_filter is None:
            return

        upload  = self.checkUploadLayers.isChecked()
        gen_rep = self.checkGenerateReport.isChecked()

        role_labels = {
            "file_a_vrs1": "Ant_A_RS1",
            "file_b_vrs1": "Ant_B_RS1",
            "file_a_vrs2": "Ant_A_RS2",
            "file_b_vrs2": "Ant_B_RS2",
        }

        try:
            self.statusBar.setText("Preprocessing in progress…")
            rep = ["="*70, "PREPROCESSING REPORT", "="*70,
                   f"Data: {preprocessing.get_current_datetime()}",
                   f"Filter: {sol_filter}", ""]
            tot_in = tot_out = 0

            for key, role in role_labels.items():
                self.statusBar.setText(f"Processing {role}…")
                if files[key].lower().endswith(".pos"):
                    stats = preprocessing.preprocess_rtklib_pos(
                        files[key], out_folder, solution_filter=sol_filter)
                else:
                    stats = preprocessing.preprocess_ppktrack(
                        files[key], out_folder, solution_filter=sol_filter)
                tot_in  += stats['total_records']
                tot_out += stats['output_records']
                rep += [f"[{role}]  {os.path.basename(files[key])}",
                        f"  Total:  {stats['total_records']}"]
                for st, cnt in stats.get('type_counts', {}).items():
                    rep.append(f"    {st}: {cnt}")
                rep += [f"  Output: {stats['output_records']}", ""]

                if upload:
                    fp  = stats['output_file'].replace('\\', '/')
                    uri = (f"file:///{fp}?delimiter=,&xField=Longitude"
                           f"&yField=Latitude&crs=EPSG:4326&useHeader=yes")
                    lyr = QgsVectorLayer(uri, role, "delimitedtext")
                    if lyr.isValid():
                        QgsProject.instance().addMapLayer(lyr)
                        rep.append(f"  \u2713 Layer: {role} ({lyr.featureCount()} feat)")
                    else:
                        rep.append(f"  \u2717 Layer {role}: {lyr.error().message()}")
                    rep.append("")

            if gen_rep:
                rp = os.path.join(out_folder, "report.txt")
                with open(rp, "a", encoding="utf-8") as f:
                    f.write("\n".join(rep) + "\n\n")

            self.statusBar.setText(
                f"Preprocessing complete — {tot_in} epochs in, {tot_out} out")
            msg = (f"Preprocessing complete!\n\n"
                   f"Total epochs: {tot_in}\nOutput epochs: {tot_out}")
            if gen_rep:
                msg += f"\n\nReport: {os.path.join(out_folder,'report.txt')}"
            QMessageBox.information(self, "Successo", msg)

            if upload:
                self._populateCombos()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Preprocessing failed:\n{e}")
            self.statusBar.setText("Preprocessing failed!")

    # =========================================================================
    # TAB 2 — RS CONSENSUS + EXPORT ANTENNA CSV
    # =========================================================================

    def runVRSConsensus(self):
        av1 = self.comboConsAV1.currentText()
        av2 = self.comboConsAV2.currentText()
        bv1 = self.comboConsBV1.currentText()
        bv2 = self.comboConsBV2.currentText()
        name_a = self.lineConsNameA.text().strip() or "Consensus_A"
        name_b = self.lineConsNameB.text().strip() or "Consensus_B"

        if not all((av1, av2, bv1, bv2)):
            QMessageBox.warning(self, "Missing input",
                                "Please select all four input layers.")
            return

        gen_rep = self.checkGenerateConsensusReport.isChecked()
        rep_folder = self.lineReportFolder.text().strip()
        if gen_rep and not rep_folder:
            QMessageBox.warning(self, "Missing folder",
                                "Please select a folder for the report.")
            return

        try:
            self.statusBar.setText("Creating Consensus A…")
            sa = consensus.create_vrs_consensus(av1, av2, name_a)
            self.statusBar.setText("Creating Consensus B…")
            sb = consensus.create_vrs_consensus(bv1, bv2, name_b)

            self._cons_done = True

            factor, unit = self._getUnit()
            msg = (f"Consensus layers created!\n\n"
                   f"Consensus A ({name_a}):\n"
                   f"  RS1={sa['n_rs1']}  RS2={sa['n_rs2']}"
                   f"  Sync={sa['synchronized']} ({sa['sync_rate']:.1f}%)\n"
                   f"  RMS 2D = {sa['rs_stats']['horizontal']['rms']*factor:.3f} {unit}"
                   f"  RMS dU = {sa['rs_stats']['height']['rms']*factor:.3f} {unit}\n\n"
                   f"Consensus B ({name_b}):\n"
                   f"  RS1={sb['n_rs1']}  RS2={sb['n_rs2']}"
                   f"  Sync={sb['synchronized']} ({sb['sync_rate']:.1f}%)\n"
                   f"  RMS 2D = {sb['rs_stats']['horizontal']['rms']*factor:.3f} {unit}"
                   f"  RMS dU = {sb['rs_stats']['height']['rms']*factor:.3f} {unit}")

            if gen_rep:
                rp = os.path.join(rep_folder, "report.txt")
                with open(rp, "a", encoding="utf-8") as f:
                    for lbl, st in (("Consensus A", sa), ("Consensus B", sb)):
                        f.write("="*70+"\n")
                        f.write(f"RS CONSENSUS — {lbl}\n")
                        f.write("="*70+"\n")
                        f.write(f"Date: {preprocessing.get_current_datetime()}\n")
                        f.write(f"Sync: {st['synchronized']} epoch"
                                f" ({st['sync_rate']:.1f}%)\n\n")
                        for key, label in (('3d','3D'),('horizontal','Orizzontale'),
                                           ('height','Quota')):
                            s = st['rs_stats'].get(key, {})
                            if s:
                                f.write(f"  {label}: RMS={s['rms']*1000:.2f} mm"
                                        f"  mean={s['mean']*1000:.2f} mm"
                                        f"  max={s['max']*1000:.2f} mm\n")
                        f.write("\n")
                msg += f"\n\nReport: {rp}"

            self.statusBar.setText("RS Consensus complete!")
            QMessageBox.information(self, "Successo", msg)
            self._populateCombos()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Consensus failed:\n{e}")
            self.statusBar.setText("Consensus failed!")

    def _exportAntennaCsv(self, layer_name, label):
        """Logica comune per export antenna A o B."""
        if not layer_name:
            QMessageBox.warning(self, "Missing layer",
                                f"The {label} consensus layer name is empty.")
            return

        out_folder = self._requireFolder(self.lineAntOutputFolder,
                                         "the {label} .txt file")
        if out_folder is None:
            return

        out_file = os.path.join(out_folder,
                                f"antenna_{'A' if label.endswith('A') else 'B'}.txt")
        try:
            self.statusBar.setText(f"Exporting {label} .txt…")
            stats = inter_receiver.export_antenna_csv(layer_name, out_file)
            factor, unit = self._getUnit()

            msg = (f"CSV {label} generato!\n\n"
                   f"File: {out_file}\n"
                   f"Epochs: {stats['n_epochs']}\n\n"
                   f"RS difference (RS1−RS2):\n"
                   f"  dN  RMS={stats['dN']['rms']*factor:.3f} {unit}"
                   f"  mean={stats['dN']['mean']*factor:+.3f} {unit}\n"
                   f"  dE  RMS={stats['dE']['rms']*factor:.3f} {unit}"
                   f"  mean={stats['dE']['mean']*factor:+.3f} {unit}\n"
                   f"  dU  RMS={stats['dU']['rms']*factor:.3f} {unit}"
                   f"  mean={stats['dU']['mean']*factor:+.3f} {unit}")

            self.statusBar.setText(f"Export {label} complete!")
            QMessageBox.information(self, "Successo", msg)

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Export {label} failed:\n{e}")
            self.statusBar.setText(f"Export {label} failed!")

    def exportAntennaA(self):
        self._exportAntennaCsv(
            self.lineConsNameA.text().strip() or "Consensus_A", "Antenna A")

    def exportAntennaB(self):
        self._exportAntennaCsv(
            self.lineConsNameB.text().strip() or "Consensus_B", "Antenna B")

    # =========================================================================
    # TAB 3 — INTER-RECEIVER + EXPORT BASELINE CSV
    # =========================================================================

    def runInterReceiver(self):
        lay_a = self.comboLayerA.currentText()
        lay_b = self.comboLayerB.currentText()
        baseline_ref = self.spinBaselineRef.value()
        baseline_ref_up = self.spinBaselineRefUp.value()
        if not lay_a or not lay_b:
            QMessageBox.warning(self, "Missing input",
                                "Please select both consensus layers.")
            return

        try:
            self.statusBar.setText("Running inter-receiver analysis…")
            color_field = self._getColorField()
            stats = inter_receiver.analyze_inter_receiver(
                lay_a, lay_b, baseline_ref, baseline_ref_up,
                color_field=color_field)
            self._ir_done = True
            factor, unit = self._getUnit()
            h = stats['stats_horiz']
            msg = (f"Inter-receiver analysis complete!\n\n"
                   f"Matched epochs: {stats['matched']}\n\n"
                   f"Horizontal baseline  |A-B|:\n"
                   f"  mean={h['mean']*factor:.3f} {unit}  "
                   f"std={h['std']*factor:.3f} {unit}  "
                   f"RMS={h['rms']*factor:.3f} {unit}  "
                   f"max={h['max']*factor:.3f} {unit}\n\n"
                   f"Layer {'Baseline_AB_Plan' if color_field == 'sigma_plan_m' else 'Baseline_AB_Vert'} "
                   f"created (classified by {color_field}).\n"
                   f"The other baseline layer (if present) is unchanged.")

            self.statusBar.setText("Inter-receiver analysis complete!")
            QMessageBox.information(self, "Success", msg)
            self._populateCombos()
            # Apply colour classification if groupbox is checked
            if self.gbColorClass.isChecked():
                self._applyColorClassification(True)

        except Exception as e:
            QMessageBox.critical(self, "Error",
                                 f"Inter-receiver analysis failed:\n{e}")
            self.statusBar.setText("Analysis failed!")

    def _getColorThresholds(self):
        """Read the four threshold spinboxes (cm → m)."""
        return [
            self.spinColorTh1.value() / 100.0,
            self.spinColorTh2.value() / 100.0,
            self.spinColorTh3.value() / 100.0,
            self.spinColorTh4.value() / 100.0,
        ]

    def _getColorField(self):
        """Return the field name for colour classification."""
        idx = self.comboColorField.currentIndex()
        return "sigma_plan_m" if idx == 0 else "sigma_vert_m"

    def _applyColorClassification(self, checked=None):
        """Apply categorised colour renderer on Baseline_AB using the
        currently selected sigma field."""
        th = self._getColorThresholds()
        colors = ["#2ecc71", "#f1c40f", "#e67e22", "#e74c3c", "#8e44ad"]
        labels = [
            f"0–{self.spinColorTh1.value()} cm",
            f"{self.spinColorTh1.value()}–{self.spinColorTh2.value()} cm",
            f"{self.spinColorTh2.value()}–{self.spinColorTh3.value()} cm",
            f"{self.spinColorTh3.value()}–{self.spinColorTh4.value()} cm",
            f">{self.spinColorTh4.value()} cm",
        ]

        def _reclassify_layer(layer, color_field):
            idx_cc  = layer.fields().indexFromName("color_class")
            idx_val = layer.fields().indexFromName(color_field)
            if idx_cc < 0 or idx_val < 0:
                return
            if not self.gbColorClass.isChecked():
                layer.setRenderer(
                    QgsVectorLayer("Point", "tmp", "memory").renderer().clone())
                layer.triggerRepaint()
                return
            attr_map = {}
            for feat in layer.getFeatures():
                v = feat[color_field]
                if v is None:
                    continue
                v = abs(float(v))
                if v <= th[0]:   cls = 1
                elif v <= th[1]: cls = 2
                elif v <= th[2]: cls = 3
                elif v <= th[3]: cls = 4
                else:            cls = 5
                attr_map[feat.id()] = {idx_cc: cls}
            layer.dataProvider().changeAttributeValues(attr_map)
            categories = []
            for i in range(5):
                sym = QgsMarkerSymbol.createSimple({
                    "color": colors[i], "size": "2.0", "outline_style": "no"})
                categories.append(QgsRendererCategory(i + 1, sym, labels[i]))
            layer.setRenderer(
                QgsCategorizedSymbolRenderer("color_class", categories))
            layer.triggerRepaint()

        applied = []
        for lname, field in (("Baseline_AB_Plan", "sigma_plan_m"),
                             ("Baseline_AB_Vert", "sigma_vert_m")):
            lys = QgsProject.instance().mapLayersByName(lname)
            if lys:
                _reclassify_layer(lys[0], field)
                applied.append(lname)
        if applied:
            self.statusBar.setText(
                "Colour classification applied to: " + ", ".join(applied))

    def exportBaseline(self):
        lay_a = self.comboLayerA.currentText()
        lay_b = self.comboLayerB.currentText()
        if not lay_a or not lay_b:
            QMessageBox.warning(self, "Missing input",
                                "Please select both consensus layers.")
            return
        if not self._ir_done:
            QMessageBox.warning(self, "Analysis not run yet",
                "Please run 'Run Inter-Receiver Analysis' first.")
            return

        out_folder = self._requireFolder(self.lineBaselineOutputFolder,
                                         "il CSV baseline")
        if out_folder is None:
            return

        out_file       = os.path.join(out_folder, "baseline_AB.txt")
        baseline_ref   = self.spinBaselineRef.value()
        baseline_ref_up = self.spinBaselineRefUp.value()

        try:
            self.statusBar.setText("Exporting Baseline AB .txt…")
            stats = inter_receiver.export_baseline_csv(
                lay_a, lay_b, out_file, baseline_ref, baseline_ref_up)
            factor, unit = self._getUnit()

            msg = (f"Baseline AB CSV exported!\n\n"
                   f"File: {out_file}\n"
                   f"Epochs: {stats['n_epochs']}\n\n"
                   f"Combined sigma planimetric:\n"
                   f"  mean={stats['sigma_plan_mean']*factor:.4f} {unit}  "
                   f"RMS={stats['sigma_plan_rms']*factor:.4f} {unit}\n\n"
                   f"Combined sigma vertical:\n"
                   f"  mean={stats['sigma_vert_mean']*factor:.4f} {unit}  "
                   f"RMS={stats['sigma_vert_rms']*factor:.4f} {unit}")
                   #f"err2D RMS vs ref {baseline_ref*factor:.3f} {unit} = "
                   #f"{stats['err2D_rms']*factor:.4f} {unit}")

            self.statusBar.setText("Baseline export complete!")
            QMessageBox.information(self, "Success", msg)

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Baseline export failed:\n{e}")
            self.statusBar.setText("Baseline export failed!")

    # =========================================================================
    # TAB 4 — STATIC PRECISION
    # =========================================================================

    def runStaticPrecision(self):
        layer_name = self.comboVehicleLayer.currentText()

        if not layer_name:
            QMessageBox.warning(self, "Missing input",
                                "Please select a layer.")
            return

        txt = self.comboUnitSP.currentText()
        if txt.startswith("cm"):
            factor, unit = 100.0, "cm"
        elif txt.startswith("mm"):
            factor, unit = 1000.0, "mm"
        else:
            factor, unit = 1.0, "m"

        try:
            self.statusBar.setText("Detecting static segments…")
            min_ep   = self.spinMinEpochs.value()
            speed_th = self.spinSpeedThreshold.value()

            result = static_precision.analyze_static_precision(
                layer_name, min_ep, speed_th)
            report = static_precision.format_report(
                result, factor, unit, header=layer_name)
            self._sp_result = result
            n_seg = len(result["segments"])

            self.textStaticResults.setPlainText(report)
            self.statusBar.setText(
                f"Static precision: {n_seg} segment(s) detected.")

        except Exception as e:
            QMessageBox.critical(self, "Error",
                                 f"Analysis failed:\n{e}")
            self.statusBar.setText("Analysis failed!")

    def exportStaticReport(self):
        """Export the static precision report to a .txt file."""
        if not hasattr(self, '_sp_result') or self._sp_result is None:
            QMessageBox.warning(self, "No results",
                                "Please run the analysis first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save static precision report",
            "", "Text files (*.txt)")
        if not path:
            return
        # The text already displayed in the widget is the authoritative report
        report = self.textStaticResults.toPlainText()
        with open(path, 'w', encoding="utf-8") as f:
            f.write(report)
        self.statusBar.setText(f"Report exported to {path}")
        QMessageBox.information(self, "Success",
                                f"Report saved to:\n{path}")

    # =========================================================================
    # TAB 5 — VISUALIZATION
    # =========================================================================

    def _getUnit(self):
        """Restituisce (fattore, etichetta) in base alla combo unità."""
        txt = self.comboUnit.currentText()
        if txt.startswith("cm"):
            return 100.0, "cm"
        if txt.startswith("mm"):
            return 1000.0, "mm"
        return 1.0, "m"

    def runVisualization(self):
        layer_name = self.comboAnalysisLayer.currentText()
        if not layer_name:
            QMessageBox.warning(self, "Missing input",
                                "Please select an analysis layer.")
            return

        checks = [self.checkPlotHorizHist, self.checkPlotHeightHist,
                  self.checkPlotBoxplot,   self.checkPlotScatterEN,
                  self.checkPlotTimeSeries, self.checkPlotTimeSeriesHeight]
        if not any(c.isChecked() for c in checks):
            QMessageBox.warning(self, "No plots selected",
                                "Please select at least one plot type.")
            return

        out_folder = QFileDialog.getExistingDirectory(
            self, "Select output folder for plots")
        if not out_folder:
            return

        try:
            self.statusBar.setText("Generating plots…")
            files = visualization.generate_plots(
                layer_name, out_folder,
                self.checkPlotHorizHist.isChecked(),
                self.checkPlotHeightHist.isChecked(),
                self.checkPlotTimeSeries.isChecked(),
                self.checkPlotBoxplot.isChecked(),
                self.checkPlotScatterEN.isChecked(),
                self.checkPlotTimeSeriesHeight.isChecked())

            msg = f"Plots generated ({len(files)}):\n"
            for f in files:
                msg += f"  \u2022 {os.path.basename(f)}\n"
            self.statusBar.setText("Plots generated!")
            QMessageBox.information(self, "Successo", msg)

        except Exception as e:
            QMessageBox.critical(self, "Error",
                                 f"Plot generation failed:\n{e}")
            self.statusBar.setText("Plot generation failed!")

    def showStatistics(self):
        """Calcola e mostra statistiche dal layer selezionato."""
        layer_name  = self.comboAnalysisLayer.currentText()
        factor, unit = self._getUnit()

        if not layer_name:
            QMessageBox.warning(self, "Missing input",
                                "Please select a layer.")
            return

        lys = QgsProject.instance().mapLayersByName(layer_name)
        if not lys:
            QMessageBox.warning(self, "Layer not found",
                                f"Layer '{layer_name}' not found.")
            return
        layer = lys[0]
        field_names = [f.name() for f in layer.fields()]

        # ── determina automaticamente il tipo di analisi dal layer ────────────
        if layer_name in ("Baseline_AB_Plan", "Baseline_AB_Vert", "Baseline_AB"):
            stats_type = "Baseline"
        elif "dE_rs" in field_names:
            stats_type = "Antenna A" if "Consensus_A" in layer_name else "Antenna B"
        else:
            stats_type = "Baseline"

        def fmt(arr, signed=False):
            mn  = np.mean(arr)   * factor
            std = np.std(arr)    * factor
            rms = np.sqrt(np.mean(arr**2)) * factor
            p95 = np.percentile(np.abs(arr), 95) * factor
            mx  = np.max(np.abs(arr)) * factor
            sg  = "+" if signed else ""
            return (f"  mean={mn:{sg}.3f} {unit}  std={std:.3f} {unit}"
                    f"  RMS={rms:.3f} {unit}  P95={p95:.3f} {unit}"
                    f"  max={mx:.3f} {unit}")

        if stats_type in ("Antenna A", "Antenna B"):
            required = ('dE_rs', 'dN_rs', 'dU_rs', 'RMS2D_rs', 'RMSUp_rs')
            missing  = [f for f in required if f not in field_names]
            if missing:
                self.textStats.setPlainText(
                    f"Missing fields for RS analysis:\n  {', '.join(missing)}\n\n"
                    "Please run RS Consensus (Tab 2) first.")
                return

            rows_dE, rows_dN, rows_dU, rows_r2, rows_rU = [], [], [], [], []
            for feat in layer.getFeatures():
                vals = (feat['dE_rs'], feat['dN_rs'], feat['dU_rs'],
                        feat['RMS2D_rs'], feat['RMSUp_rs'])
                if None in vals:
                    continue
                try:
                    rows_dE.append(float(vals[0])); rows_dN.append(float(vals[1]))
                    rows_dU.append(float(vals[2])); rows_r2.append(float(vals[3]))
                    rows_rU.append(float(vals[4]))
                except (ValueError, TypeError):
                    continue

            if not rows_dE:
                self.textStats.setPlainText("No valid data found in layer.")
                return

            dE = np.array(rows_dE); dN = np.array(rows_dN); dU = np.array(rows_dU)
            r2 = np.array(rows_r2); rU = np.array(rows_rU)
            ant_lbl = "A" if stats_type == "Antenna A" else "B"
            lines = [
                f"Layer: {layer_name}   —   Antenna {ant_lbl}   —   {len(dE)} epochs",
                f"Unit: {unit}\n",
                "━"*60,
                "dE  (East component   RS1−RS2)",
                fmt(dE, signed=True),
                "dN  (North component  RS1−RS2)",
                fmt(dN, signed=True),
                "dU  (Up component     RS1−RS2)",
                fmt(dU, signed=True),
                "",
                "━"*60,
                "Δ₂D = √(ΔE² + ΔN²)   (horizontal RS difference per epoch)",
                fmt(r2),
                "Δᵤ = |ΔU|   (vertical RS difference per epoch)",
                fmt(rU),
            ]

        else:  # Baseline
            if layer_name in ("Baseline_AB_Plan", "Baseline_AB_Vert", "Baseline_AB"):
                required = ('baseline_2D_m', 'delta_h_abs_m', 'sigma_plan_m', 'sigma_vert_m')
            else:
                required = ('DIST_HORIZ', 'DIFF_HEIGHT', 'DELTA_E', 'DELTA_N')
            missing  = [f for f in required if f not in field_names]
            if missing:
                self.textStats.setPlainText(
                    f"Missing fields for Baseline analysis:\n  {', '.join(missing)}\n\n"
                    "Please run Inter-Receiver Analysis (Tab 3) first.")
                return

            if layer_name in ("Baseline_AB_Plan", "Baseline_AB_Vert", "Baseline_AB"):
                rows_b2d, rows_dh, rows_sp, rows_sv = [], [], [], []
                for feat in layer.getFeatures():
                    vals = (feat['baseline_2D_m'], feat['delta_h_abs_m'],
                            feat['sigma_plan_m'], feat['sigma_vert_m'])
                    if None in vals:
                        continue
                    try:
                        rows_b2d.append(abs(float(vals[0])))
                        rows_dh.append(abs(float(vals[1])))
                        rows_sp.append(abs(float(vals[2])))
                        rows_sv.append(abs(float(vals[3])))
                    except (ValueError, TypeError):
                        continue

                if not rows_b2d:
                    self.textStats.setPlainText("No valid data found in layer.")
                    return

                b2d = np.array(rows_b2d); dh = np.array(rows_dh)
                sp  = np.array(rows_sp);  sv = np.array(rows_sv)

                # Reference values from Tab 3 spinboxes
                ref_2d = self.spinBaselineRef.value()
                ref_up = abs(self.spinBaselineRefUp.value())
                err_2d = b2d - ref_2d     # signed residual horizontal
                err_h  = dh  - ref_up     # signed residual vertical

                lines = [
                    f"Layer: {layer_name}   —   Baseline A-B   —   {len(b2d)} epochs",
                    f"Unit: {unit}   "
                    f"Ref horizontal = {ref_2d:.3f} m   Ref height = {ref_up:.3f} m\n",
                    "═" * 60,
                    "Horizontal baseline  |A−B|",
                    fmt(b2d),
                    "",
                    "Delta H  |ΔU|",
                    fmt(dh),
                    "",
                    "═" * 60,
                    f"Error vs reference  (|A−B| − {ref_2d:.3f} m)",
                    fmt(err_2d, signed=True),
                    "",
                    f"Error vs reference  (|ΔH| − {ref_up:.3f} m)",
                    fmt(err_h, signed=True),
                    "",
                    "═" * 60,
                    "Combined sigma planimetric",
                    fmt(sp),
                    "",
                    "Combined sigma vertical",
                    fmt(sv),
                ]
            else:
                rows_v = {r: [] for r in required}
                for feat in layer.getFeatures():
                    skip = False
                    for r in required:
                        v = feat[r]
                        if v is None:
                            skip = True; break
                        rows_v[r].append(abs(float(v)))
                    if skip:
                        continue
                if not rows_v[required[0]]:
                    self.textStats.setPlainText("No valid data found in layer.")
                    return
                lines = [f"Layer: {layer_name}   ---   {len(rows_v[required[0]])} epochs",
                         f"Unit: {unit}\n", "=" * 60]
                for r in required:
                    arr = np.array(rows_v[r])
                    lines.extend([r, fmt(arr), ""])

        self.textStats.setPlainText("\n".join(lines))
        self.statusBar.setText(
            f"Statistics computed — {layer_name} — unit: {unit}")

    # =========================================================================
    # MISC
    # =========================================================================

    def showOutputLegend(self):
        OutputLegendDialog(self).exec_()

    def showInputFormat(self):
        """Open a dedicated dialog showing the input format documentation."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QPlainTextEdit,
                                          QPushButton, QHBoxLayout)
        from qgis.PyQt.QtGui import QFont
        from .output_legend_dialog import INPUT_FORMAT_NOTE

        dlg = QDialog(self)
        dlg.setWindowTitle("Input file format")
        dlg.setMinimumSize(700, 520)
        layout = QVBoxLayout(dlg)

        text_edit = QPlainTextEdit()
        text_edit.setReadOnly(True)
        text_edit.setPlainText(INPUT_FORMAT_NOTE)
        text_edit.setFont(QFont("Courier New", 9))
        text_edit.setStyleSheet(
            "background: #fffde7; border: 1px solid #dee2e6; border-radius: 4px;")
        layout.addWidget(text_edit)

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_close = QPushButton("Close")
        btn_close.setFixedWidth(100)
        btn_close.clicked.connect(dlg.accept)
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)

        dlg.exec_()

    def showEvent(self, event):
        super().showEvent(event)
        self._populateCombos()

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()
