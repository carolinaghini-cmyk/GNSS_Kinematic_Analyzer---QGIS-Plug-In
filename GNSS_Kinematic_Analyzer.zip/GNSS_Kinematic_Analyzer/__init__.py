# -*- coding: utf-8 -*-

def classFactory(iface):
    from .gnss_kinematic_analyzer import GNSSKinematicAnalyzer
    return GNSSKinematicAnalyzer(iface)